# AccessPatch v2 — USA.gov (SanD Hacks)

Client-side accessibility for USA.gov. Only changes what *you* see in *your* browser — like zoom or a screen reader. No server changes, no login bypass.

Built from W3C WAI Intro to Web Accessibility: people must be able to **perceive, understand, navigate, and interact** — including older people with changing abilities and people who cannot use a mouse. Source: https://www.w3.org/WAI/fundamentals/accessibility-intro/

## What's new in v2
- **Gleam ✨ — mascot in the guide box.** Friendly glowing star. Stays with you the whole time, speaks slowly, says "Take your time. You can't break anything."
- **Keyword guide — specific, not generic.** Gleam asks "What do you want to do today?" Type `fill tax` (or tap Taxes / Benefits / Passport / Social Security / Health / Voting). Gleam searches the *actual page* for matching links and shows only 3-4 options as huge buttons. Pick one, Gleam walks you Step 1-2-3 to that exact link.
- **Senior-proof flow:** 1 instruction per screen, short plain sentences, huge 60px buttons, always a Back button and an "I'm lost — start over" button.
- **Spotlight:** when Gleam highlights the next link, the rest of the page dims. You literally cannot get lost.
- **MUCH more visible:** Elderly mode is now 24px text, warm cream background, 46px headings, yellow banner "Easy Read is ON", nav/footer/banners/images hidden, buttons yellow + 60px tall. Low Vision is black background + yellow links.

## Load it
1. Chrome → `chrome://extensions` → Developer mode on
2. Load unpacked → select this folder
3. Go to https://www.usa.gov — Gleam pops up automatically

## Demo script (3-min video, tax example)
0:00 Problem: seniors get lost and stressed even on simple gov sites
0:15 Before: USA.gov normal — small, dense, cluttered
0:30 After: Elderly mode on — huge text, cream background, clutter gone
0:50 Gleam: type "fill tax" → shows only tax options → pick "File taxes"
1:20 Spotlight: rest dims, one yellow link glows, Step 1-2-3 + voice reads it
2:00 Low Vision switch, Read Page aloud
2:20 How it works: keyword → JSON patch in `patches.json` → content script injects overlay, W3C principles
2:45 Impact + next: any gov site, ElevenLabs voice, Gemini to auto-summarize next page

## Next
- ElevenLabs TTS (Best with ElevenLabs track) — replace `speechSynthesis` in `content.js`
- Remember the keyword across pages so Gleam follows you to the next page
- Gemini: auto-explain the next page in 3 simple steps

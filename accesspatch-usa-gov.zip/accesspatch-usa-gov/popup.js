chrome.storage.local.get(["profile"], r => {
  if (r.profile) document.getElementById("profile").value = r.profile;
});
document.getElementById("save").addEventListener("click", async () => {
  const profile = document.getElementById("profile").value;
  await chrome.storage.local.set({ profile });
  document.getElementById("status").textContent = "Saved! Reload USA.gov to see it.";
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.url?.includes("usa.gov")) chrome.tabs.reload(tab.id);
});
